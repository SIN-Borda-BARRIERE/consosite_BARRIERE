<?php
// api/export_csv.php
session_start();
require_once "../database.php";

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    exit;
}

header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="consommation_electrique.csv"');
header('Pragma: no-cache');
header('Expires: 0');

echo "\xEF\xBB\xBF"; // UTF-8 BOM for Excel

$output = fopen('php://output', 'w');

fputcsv($output, ['Date', 'Consommation (kWh)']);

$stmt = $pdo->prepare("
    SELECT date, kwh
    FROM electricity_consumption
    WHERE user_id = ?
    ORDER BY date ASC
");
$stmt->execute([$_SESSION['user_id']]);

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    fputcsv($output, [
        $row['date'],
        number_format($row['kwh'], 2, '.', '')
    ]);
}

fclose($output);
exit;
