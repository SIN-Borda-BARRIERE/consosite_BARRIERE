<?php
session_start();
require_once "../database.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}

if (!isset($_FILES['avatar']) || $_FILES['avatar']['error'] !== 0) {
    die("Erreur upload");
}

$allowed = ['image/jpeg', 'image/png', 'image/webp'];
if (!in_array($_FILES['avatar']['type'], $allowed)) {
    die("Format non autorisé");
}

$ext = pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION);
$filename = uniqid("avatar_") . "." . $ext;

$destination = "../avatars/" . $filename;

if (!move_uploaded_file($_FILES['avatar']['tmp_name'], $destination)) {
    die("Échec sauvegarde");
}

$stmt = $pdo->prepare("UPDATE users SET avatar = ? WHERE id = ?");
$stmt->execute([$filename, $_SESSION['user_id']]);

header("Location: ../pages/homepage.php");
exit;
