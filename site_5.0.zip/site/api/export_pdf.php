<?php
// api/export_pdf.php
session_start();
require_once "../database.php";
require_once "../lib/dompdf-master/autoload.inc.php";

use Dompdf\Dompdf;
use Dompdf\Options;

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

$stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$username = htmlspecialchars($stmt->fetchColumn());

$date = date("d/m/Y H:i");

$html = '
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<style>
body { font-family: DejaVu Sans, sans-serif; }
h1 { margin-bottom: 5px; }
.info { margin-bottom: 15px; }
.stats { margin-bottom: 20px; }
img { width: 100%; }
</style>
</head>
<body>

<h1>Dashboard énergétique</h1>

<div class="info">
<strong>Utilisateur :</strong> ' . $username . '<br>
<strong>Date :</strong> ' . $date . '<br>
<strong>Période :</strong> ' . htmlspecialchars($data['period']) . ' (' . htmlspecialchars($data['range']) . ')
</div>

<div class="stats">
' . $data['stats'] . '
</div>

<img src="' . $data['chart'] . '">

</body>
</html>
';

$options = new Options();
$options->set('isRemoteEnabled', true);

$dompdf = new Dompdf($options);
$dompdf->loadHtml($html, 'UTF-8');
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();

$dompdf->stream("dashboard.pdf", ["Attachment" => true]);
exit;
