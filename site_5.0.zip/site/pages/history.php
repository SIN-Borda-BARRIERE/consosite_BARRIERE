<?php
session_start();
require_once "../database.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}

// Récupération du pseudo utilisateur
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT username, avatar FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
$username = htmlspecialchars($user['username']);
$avatar   = htmlspecialchars($user['avatar']);
$user_id = $_SESSION['user_id'];
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Historique</title>
    <link rel="stylesheet" href="../style.css">
    <script src="../app.js?v=<?= time() ?>" defer></script>
</head>
<body>

<header>
    <div class="header-left">
        <h1>Gestion énergétique</h1>
        <nav>
            <a href="homepage.php">Accueil</a>
            <a href="history.php">Historique</a>
            <a href="dashboard.php">Tableau de bord</a>
            <a href="../auth/logout.php">Déconnexion</a>
        </nav>
    </div>

    <div class="header-right">
        <span>Bienvenue, <strong><?= $username ?></strong></span>
        <img src="../avatars/<?= $avatar ?>" class="avatar">
    </div>
</header>

<h2>Historique des consommations</h2>

<div class="history-controls">
    <button id="show-add-form">➕ Ajouter une consommation</button>
    <button id="export-csv">⬇️ Export CSV</button>

    <button class="filter-btn" data-period="day">Jour</button>
    <button class="filter-btn" data-period="week">Semaine</button>
    <button class="filter-btn" data-period="month">Mois</button>
</div>

<form id="add-history-form" style="display:none; margin-top:10px;">
    <input type="date" id="history-date" required>
    <input type="number" step="0.01" id="history-kwh" required>
    <button type="submit">Enregistrer</button>
    <button type="button" id="cancel-add">Annuler</button>
</form>

<p id="history-message"></p>

<table border="1" style="margin-top:20px;">
    <thead>
        <tr>
            <th>Date</th>
            <th>kWh</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody id="history-table"></tbody>
</table>

</body>
</html>
