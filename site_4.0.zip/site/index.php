<?php
header("Location: pages/homepage.php");
exit;
?>
