<?php
require_once "../database.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
    $stmt->execute([$username, $password]);

    $success = true;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Inscription</title>
    <link rel="stylesheet" href="../style.css">
    <script src="../app.js" defer></script>
</head>
<body class="auth-body">

<div class="auth-card">
    <h2>Inscription</h2>

    <?php if (!empty($success)): ?>
        <p class="auth-success">
            Compte créé !
            <a href="login.php">Se connecter</a>
        </p>
    <?php endif; ?>

    <form method="post" class="auth-form">
        <input type="text" name="username" placeholder="Nom d'utilisateur" required>
        <input type="password" name="password" placeholder="Mot de passe" required>
        <button type="submit">S'inscrire</button>
    </form>

    <p class="auth-footer">
        Déjà un compte?
        <a href="login.php">Se connecter</a>
    </p>
</div>

</body>
</html>
