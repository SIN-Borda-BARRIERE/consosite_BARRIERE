USE energy_tracker;

-- ================================
-- USER TEST (LOGIN SIMPLE)
-- ================================
INSERT INTO users (username, password)
SELECT 'test', 'test1'
WHERE NOT EXISTS (
    SELECT 1 FROM users WHERE username = 'test'
);

SET @user_id := (SELECT id FROM users WHERE username = 'test');

-- ================================
-- TABLE TEMPORAIRE DE DATES
-- ================================
DROP TEMPORARY TABLE IF EXISTS temp_dates;

CREATE TEMPORARY TABLE temp_dates (
    d DATE PRIMARY KEY
);

-- ================================
-- GÉNÉRATION DES DATES
-- ================================
INSERT IGNORE INTO temp_dates (d)
SELECT DATE('2025-01-01') + INTERVAL seq DAY
FROM (
    SELECT a.n + b.n * 10 + c.n * 100 AS seq
    FROM
        (SELECT 0 n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4
         UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) a,
        (SELECT 0 n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4
         UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) b,
        (SELECT 0 n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3) c
) numbers
WHERE DATE('2025-01-01') + INTERVAL seq DAY <= '2026-01-21';

-- ================================
-- INSERT CONSOMMATION SAISONNIÈRE
-- ================================
INSERT INTO electricity_consumption (user_id, date, kwh)
SELECT
    @user_id,
    t.d,
    ROUND(
        CASE
            -- Hiver
            WHEN MONTH(t.d) IN (12,1,2) THEN 22 + RAND() * 8
            -- Printemps
            WHEN MONTH(t.d) IN (3,4,5) THEN 15 + RAND() * 6
            -- Été
            WHEN MONTH(t.d) IN (6,7,8) THEN 18 + RAND() * 7
            -- Automne
            ELSE 16 + RAND() * 5
        END,
        2
    )
FROM temp_dates t
WHERE NOT EXISTS (
    SELECT 1
    FROM electricity_consumption ec
    WHERE ec.user_id = @user_id
      AND ec.date = t.d
);

-- ================================
-- VÉRIFICATION
-- ================================
SELECT
    u.username,
    COUNT(ec.id) AS jours,
    MIN(ec.date) AS debut,
    MAX(ec.date) AS fin,
    ROUND(AVG(ec.kwh),2) AS moyenne_kwh
FROM users u
JOIN electricity_consumption ec ON ec.user_id = u.id
WHERE u.username = 'test'
GROUP BY u.username;
