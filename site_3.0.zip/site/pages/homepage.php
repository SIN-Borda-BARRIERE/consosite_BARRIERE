<?php
session_start();
require_once "../database.php";

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT username, avatar FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

$username = htmlspecialchars($user['username']);
$avatar   = htmlspecialchars($user['avatar']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Accueil - Gestion Énergie</title>
    <link rel="stylesheet" href="../style.css">
    <script src="../app.js?v=<?= time() ?>" defer></script>
</head>
<body>

<header class="main-header">
    <div class="header-left">
        <h1>Gestion énergétique</h1>
        <nav>
            <a href="homepage.php">Accueil</a>
            <a href="history.php">Historique</a>
            <a href="dashboard.php">Tableau de bord</a>
            <a href="../auth/logout.php">Déconnexion</a>
        </nav>
    </div>

    <div class="header-right">
        <span>Bienvenue, <strong><?= $username ?></strong></span>
        <img src="../uploads/avatars/<?= $avatar ?>" class="avatar">
    </div>
</header>

<main>

<section>
    <h2>Ajouter la consommation du jour</h2>

    <form id="electricity-form">
        <label>Consommation (kWh)</label>
        <input type="number" step="0.01" id="kwh" required>
        <button type="submit">Enregistrer</button>
    </form>

    <p id="form-message"></p>
</section>

<section>
    <h2>Photo de profil</h2>

    <form action="../api/upload_avatar.php" method="post" enctype="multipart/form-data">
        <input type="file" name="avatar" accept="image/*" required>
        <button type="submit">Changer la photo</button>
    </form>
</section>

</main>
</body>
</html>
