document.addEventListener("DOMContentLoaded", () => {

    /* ======================
       HOMEPAGE
    ====================== */
    const homeForm = document.getElementById("electricity-form");

    if (homeForm) {
        homeForm.addEventListener("submit", e => {
            e.preventDefault();

            fetch("../api/save_value.php", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    kwh: document.getElementById("kwh").value
                })
            })
            .then(res => res.json())
            .then(data => {
                const msg = document.getElementById("form-message");
                msg.textContent = data.updated
                    ? "⚠ Consommation déjà enregistrée pour aujourd'hui (mise à jour)"
                    : "✅ Consommation enregistrée";
                homeForm.reset();
            });
        });
    }
    

    /* ======================
    DASHBOARD (ADVANCED)
    ====================== */
const chartCanvas = document.getElementById("consumptionChart");
const statsBox = document.getElementById("stats-box");
const rangeSelect = document.getElementById("rangeSelect");

let chartInstance = null;
let dashboardPeriod = "day";
let rawData = [];

if (chartCanvas && window.Chart) {
    document.querySelectorAll("button[data-period]").forEach(btn => {
        btn.addEventListener("click", () => {
            dashboardPeriod = btn.dataset.period;
            loadData(dashboardPeriod);
        });
    });
    loadData("day");
}

function loadData(period) {
    fetch(`../api/get_stats.php?period=${period}`)
        .then(res => res.json())
        .then(data => {
            rawData = data;
            populateRangeSelect(period, data);
            renderChart(period, rangeSelect.value);
        });
}

function populateRangeSelect(period, data) {
    rangeSelect.innerHTML = "";
    let ranges = [];

    if (period === "day") {
        ranges = [...new Set(data.map(d => d.label.slice(0, 7)))]; // YYYY-MM
    }
    else if (period === "week") {
        ranges = ["Hiver", "Printemps", "Été", "Automne"];
    }
    else {
        ranges = [...new Set(data.map(d => d.label.slice(0, 4)))]; // YYYY
    }

    ranges.forEach(r => {
        const opt = document.createElement("option");
        opt.value = r;
        opt.textContent = r;
        rangeSelect.appendChild(opt);
    });

    rangeSelect.onchange = () => renderChart(period, rangeSelect.value);
}

function renderChart(period, range) {
    let filtered = [];

    if (period === "day") {
        filtered = rawData.filter(d => d.label.startsWith(range));
    }
    else if (period === "week") {
        const seasons = {
            "Hiver": [12, 1, 2],
            "Printemps": [3, 4, 5],
            "Été": [6, 7, 8],
            "Automne": [9, 10, 11]
        };

        filtered = rawData.filter(d => {
        const year = parseInt(d.label.slice(0, 4));
        const week = parseInt(d.label.slice(6));
        const date = new Date(year, 0, 1 + (week - 1) * 7);
        const month = date.getMonth() + 1;
        return seasons[range].includes(month);
        });
    }

    else {
        filtered = rawData.filter(d => d.label.startsWith(range));
    }

    const labels = filtered.map(d => d.label);
    const values = filtered.map(d => Number(d.total));

    if (chartInstance) chartInstance.destroy();

    chartInstance = new Chart(chartCanvas, {
        type: "line",
        data: {
            labels,
            datasets: [{
                label: "Consommation (kWh)",
                data: values,
                borderWidth: 2,
                tension: 0.3
            }]
        }
    });

    if (statsBox) {
        const total = values.reduce((a, b) => a + b, 0);
        const avg = values.length ? total / values.length : 0;
        statsBox.innerHTML = `
            <p><strong>Total :</strong> ${total.toFixed(2)} kWh</p>
            <p><strong>Moyenne :</strong> ${avg.toFixed(2)} kWh</p>
        `;
    }
}

const exportPdfBtn = document.getElementById("export-pdf");

if (exportPdfBtn) {
    exportPdfBtn.addEventListener("click", () => {
        if (!chartInstance) return;

        const { jsPDF } = window.jspdf;
        const pdf = new jsPDF("p", "mm", "a4");

        const username = document.querySelector(".header-right strong")?.textContent || "";
        const now = new Date().toLocaleString("fr-FR");

        pdf.setFontSize(14);
        pdf.text("Dashboard énergétique", 15, 15);

        pdf.setFontSize(10);
        pdf.text(`Utilisateur : ${username}`, 15, 25);
        pdf.text(`Date : ${now}`, 15, 31);
        pdf.text(`Période : ${dashboardPeriod} (${rangeSelect.value})`, 15, 37);

        // Stats
        const statsText = statsBox.innerText.split("\n");
        let y = 47;
        statsText.forEach(line => {
            pdf.text(line, 15, y);
            y += 6;
        });

        // Chart
        const img = chartInstance.toBase64Image();
        pdf.addImage(img, "PNG", 15, y + 5, 180, 90);

        pdf.save("dashboard.pdf");
    });
}


/* ======================
   HISTORY
====================== */
const historyTable = document.getElementById("history-table");
const addForm = document.getElementById("add-history-form");
const showAddBtn = document.getElementById("show-add-form");
const cancelAddBtn = document.getElementById("cancel-add");
const historyMsg = document.getElementById("history-message");
let historyPeriod = "day";

if (showAddBtn && addForm) {
    showAddBtn.addEventListener("click", () => {
        addForm.style.display = "block";
        showAddBtn.style.display = "none";
    });

    cancelAddBtn.addEventListener("click", () => {
        addForm.style.display = "none";
        showAddBtn.style.display = "inline-block";
    });
}

if (addForm) {
    addForm.addEventListener("submit", e => {
        e.preventDefault();
        if (historyPeriod !== "day") {
            historyMsg.textContent = "❌ Vous ne pouvez ajouter une consommation qu’en mode Jour.";
            return;
        }
        saveValue(
            document.getElementById("history-date").value,
            document.getElementById("history-kwh").value,
            true
        );
    });
}

if (historyTable) loadHistory("day");

document.querySelectorAll(".filter-btn").forEach(btn => {
    btn.addEventListener("click", () => {
        historyPeriod = btn.dataset.period;
        loadHistory(historyPeriod);
        historyMsg.textContent = ""; // reset messages
    });
});

function loadHistory(period) {
    fetch(`../api/get_stats.php?period=${period}`)
        .then(res => res.json())
        .then(data => {
            historyTable.innerHTML = "";
            data.forEach(row => {
                const label = row.label;
                const total = Number(row.total).toFixed(2);

                // boutons activés seulement si mode jour
                const disableActions = period !== "day";
                const editBtn = disableActions ? 
                    `<button class="edit-btn" disabled>📝</button>` : 
                    `<button class="edit-btn">📝 Modifier</button>`;
                const deleteBtn = disableActions ?
                    `<button class="delete-btn" disabled>🗑</button>` :
                    `<button class="delete-btn">🗑 Supprimer</button>`;

                historyTable.innerHTML += `
                    <tr>
                        <td>${label}</td>
                        <td><span class="kwh-value">${total}</span></td>
                        <td>${editBtn} ${deleteBtn}</td>
                    </tr>`;
            });
        });
}

if (historyTable) {
historyTable.addEventListener("click", e => {
    const row = e.target.closest("tr");
    if (!row) return;
    const date = row.querySelector("td").textContent.trim();

    if (historyPeriod !== "day") {
        historyMsg.textContent = "⚠️ Les modifications ou suppressions ne sont possibles qu’en vue 'Jour'.";
        return;
    }

    if (e.target.classList.contains("edit-btn")) {
        const valueSpan = row.querySelector(".kwh-value");
        const currentValue = valueSpan.textContent;
        row.querySelector("td:nth-child(2)").innerHTML = `
            <input type="number" step="0.01" value="${currentValue}" data-date="${date}">
        `;
        e.target.textContent = "💾 Enregistrer";
        e.target.classList.remove("edit-btn");
        e.target.classList.add("save-btn");
    }

    else if (e.target.classList.contains("save-btn")) {
        const input = row.querySelector("input[data-date]");
        saveValue(input.dataset.date, input.value, true);
    }

    else if (e.target.classList.contains("delete-btn")) {
        if (confirm("Supprimer cette consommation ?")) {
            deleteValue(date);
        }
    }
});
}

function saveValue(date, kwh, reload = false) {
    fetch("../api/save_value.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date, kwh })
    })
    .then(res => res.json())
    .then(() => {
        if (reload) loadHistory(historyPeriod);
        addForm.reset();
        addForm.style.display = "none";
        showAddBtn.style.display = "inline-block";
        confirm("Consommation modifiée")
    });
}

function deleteValue(date) {
    fetch("../api/delete_value.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date })
    })
    .then(res => res.json())
    .then(() => {
        loadHistory(historyPeriod);
        confirm("Consommation supprimé")
    });
}
//* Export csv
const exportBtn = document.getElementById("export-csv");

if (exportBtn) {
    exportBtn.addEventListener("click", () => {
        fetch("../api/export_csv.php")
            .then(res => res.blob())
            .then(blob => {
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement("a");
                a.href = url;
                a.download = "consommation_electrique.csv";
                document.body.appendChild(a);
                a.click();
                a.remove();
                window.URL.revokeObjectURL(url);
            });
    });
}

    /* ======================
       ACCOUNT MANAGEMENT
    ====================== */

    const showUsernameBtn = document.getElementById("show-username-form");
    const showPasswordBtn = document.getElementById("show-password-form");
    const showProfileBtn = document.getElementById("show-profile-form");
    const usernameForm = document.getElementById("update-username-form");
    const passwordForm = document.getElementById("update-password-form");
    const profileForm = document.getElementById("update-profile-form");
    const deleteForm = document.getElementById("delete-account-form");
    const accountMsg = document.getElementById("account-message");

    if (showUsernameBtn && usernameForm) {
        showUsernameBtn.addEventListener("click", () => {
            usernameForm.style.display = "block";
            showUsernameBtn.style.display = "none";
        });
        
    }

    if (showPasswordBtn && passwordForm) {
        showPasswordBtn.addEventListener("click", () => {
            passwordForm.style.display = "block";
            showPasswordBtn.style.display = "none";
        });
    }

    if (showProfileBtn && profileForm) {
        showProfileBtn.addEventListener("click", () => {
            profileForm.style.display = "block";
            showProfileBtn.style.display = "none";
        });
    }

    if (usernameForm) {
        usernameForm.addEventListener("submit", e => {
            e.preventDefault();
            fetch("../api/update_user.php", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    action: "update_username",
                    username: document.getElementById("new-username").value
                })
            })
            .then(res => res.json())
            .then(data => {
                accountMsg.textContent = data.success
                    ? "✅ Pseudo mis à jour avec succès."
                    : "❌ Erreur lors de la mise à jour.";
            });
        });
    }

    if (passwordForm) {
        passwordForm.addEventListener("submit", e => {
            e.preventDefault();
            fetch("../api/update_user.php", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    action: "update_password",
                    password: document.getElementById("new-password").value
                })
            })
            .then(res => res.json())
            .then(data => {
                accountMsg.textContent = data.success
                    ? "✅ Mot de passe modifié avec succès."
                    : "❌ Erreur lors de la modification.";
            });
        });
    }

    if (deleteForm) {
        deleteForm.addEventListener("submit", e => {
            e.preventDefault();
            if (confirm("Voulez-vous vraiment supprimer votre compte ?")) {
                fetch("../api/update_user.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ action: "delete_account" })
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        alert("Compte supprimé avec succès.");
                        window.location.href = "../auth/logout.php";
                    } else {
                        accountMsg.textContent = "❌ Erreur lors de la suppression du compte.";
                    }
                });
            }
        });
    }
    console.log("Script chargé !");
});