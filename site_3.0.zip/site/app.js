document.addEventListener("DOMContentLoaded", () => {
    console.log("Script chargé !");

    /* ======================
       HOMEPAGE
    ====================== */
    const homeForm = document.getElementById("electricity-form");

    if (homeForm) {
        homeForm.addEventListener("submit", e => {
            e.preventDefault();

            fetch("../api/save_value.php", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    kwh: document.getElementById("kwh").value
                })
            })
            .then(res => res.json())
            .then(data => {
                const msg = document.getElementById("form-message");
                msg.textContent = data.updated
                    ? "⚠ Consommation déjà enregistrée pour aujourd'hui (mise à jour)"
                    : "✅ Consommation enregistrée";
                homeForm.reset();
            });
        });
    }
    

    /* ======================
       DASHBOARD
    ====================== */
    const chartCanvas = document.getElementById("consumptionChart");
    const statsBox = document.getElementById("stats-box");
    let chartInstance = null;

    if (chartCanvas && window.Chart) {
        document.querySelectorAll("button[data-period]").forEach(btn => {
            btn.addEventListener("click", () => loadChart(btn.dataset.period));
        });
        loadChart("day");
    }

    function loadChart(period) {
        fetch(`../api/get_stats.php?period=${period}`)
            .then(res => res.json())
            .then(data => {
                const labels = data.map(d => d.label);
                const values = data.map(d => Number(d.total));

                if (chartInstance) chartInstance.destroy();

                chartInstance = new Chart(chartCanvas, {
                    type: "line",
                    data: {
                        labels,
                        datasets: [{
                            label: "Consommation (kWh)",
                            data: values,
                            borderWidth: 2
                        }]
                    }
                });

                if (statsBox) {
                    const total = values.reduce((a, b) => a + b, 0);
                    const avg = values.length ? (total / values.length) : 0;

                    statsBox.innerHTML = `
                        <p><strong>Total :</strong> ${total.toFixed(2)} kWh</p>
                        <p><strong>Moyenne :</strong> ${avg.toFixed(2)} kWh</p>
                    `;
                }
            });
    }

/* ======================
   HISTORY
====================== */
const historyTable = document.getElementById("history-table");
const addForm = document.getElementById("add-history-form");
const showAddBtn = document.getElementById("show-add-form");
const cancelAddBtn = document.getElementById("cancel-add");
const historyMsg = document.getElementById("history-message");
let currentPeriod = "day";

if (showAddBtn && addForm) {
    showAddBtn.addEventListener("click", () => {
        addForm.style.display = "block";
        showAddBtn.style.display = "none";
    });

    cancelAddBtn.addEventListener("click", () => {
        addForm.style.display = "none";
        showAddBtn.style.display = "inline-block";
    });
}

if (addForm) {
    addForm.addEventListener("submit", e => {
        e.preventDefault();
        if (currentPeriod !== "day") {
            historyMsg.textContent = "❌ Vous ne pouvez ajouter une consommation qu’en mode Jour.";
            return;
        }
        saveValue(
            document.getElementById("history-date").value,
            document.getElementById("history-kwh").value,
            true
        );
    });
}

if (historyTable) loadHistory("day");

document.querySelectorAll(".filter-btn").forEach(btn => {
    btn.addEventListener("click", () => {
        currentPeriod = btn.dataset.period;
        loadHistory(currentPeriod);
        historyMsg.textContent = ""; // reset messages
    });
});

function loadHistory(period) {
    fetch(`../api/get_stats.php?period=${period}`)
        .then(res => res.json())
        .then(data => {
            historyTable.innerHTML = "";
            data.forEach(row => {
                const label = row.label;
                const total = Number(row.total).toFixed(2);

                // boutons activés seulement si mode jour
                const disableActions = period !== "day";
                const editBtn = disableActions ? 
                    `<button class="edit-btn" disabled>📝</button>` : 
                    `<button class="edit-btn">📝 Modifier</button>`;
                const deleteBtn = disableActions ?
                    `<button class="delete-btn" disabled>🗑</button>` :
                    `<button class="delete-btn">🗑 Supprimer</button>`;

                historyTable.innerHTML += `
                    <tr>
                        <td>${label}</td>
                        <td><span class="kwh-value">${total}</span></td>
                        <td>${editBtn} ${deleteBtn}</td>
                    </tr>`;
            });
        });
}

historyTable.addEventListener("click", e => {
    const row = e.target.closest("tr");
    if (!row) return;
    const date = row.querySelector("td").textContent.trim();

    if (currentPeriod !== "day") {
        historyMsg.textContent = "⚠️ Les modifications ou suppressions ne sont possibles qu’en vue 'Jour'.";
        return;
    }

    if (e.target.classList.contains("edit-btn")) {
        const valueSpan = row.querySelector(".kwh-value");
        const currentValue = valueSpan.textContent;
        row.querySelector("td:nth-child(2)").innerHTML = `
            <input type="number" step="0.01" value="${currentValue}" data-date="${date}">
        `;
        e.target.textContent = "💾 Enregistrer";
        e.target.classList.remove("edit-btn");
        e.target.classList.add("save-btn");
    }

    else if (e.target.classList.contains("save-btn")) {
        const input = row.querySelector("input[data-date]");
        saveValue(input.dataset.date, input.value, true);
    }

    else if (e.target.classList.contains("delete-btn")) {
        if (confirm("Supprimer cette consommation ?")) {
            deleteValue(date);
        }
    }
});

function saveValue(date, kwh, reload = false) {
    fetch("../api/save_value.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date, kwh })
    })
    .then(res => res.json())
    .then(() => {
        if (reload) loadHistory(currentPeriod);
        addForm.reset();
        addForm.style.display = "none";
        showAddBtn.style.display = "inline-block";
        historyMsg.textContent = "✅ Donnée enregistrée avec succès.";
    });
}

function deleteValue(date) {
    fetch("../api/delete_value.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date })
    })
    .then(res => res.json())
    .then(() => {
        loadHistory(currentPeriod);
        historyMsg.textContent = "🗑 Donnée supprimée.";
    });
}




    /* ======================
       ACCOUNT MANAGEMENT
    ====================== */

    const showUsernameBtn = document.getElementById("show-username-form");
    const showPasswordBtn = document.getElementById("show-password-form");
    const usernameForm = document.getElementById("update-username-form");
    const passwordForm = document.getElementById("update-password-form");
    const deleteForm = document.getElementById("delete-account-form");
    const accountMsg = document.getElementById("account-message");

    if (showUsernameBtn && usernameForm) {
        showUsernameBtn.addEventListener("click", () => {
            usernameForm.style.display = "block";
            showUsernameBtn.style.display = "none";
        });
        
    }

    if (showPasswordBtn && passwordForm) {
        showPasswordBtn.addEventListener("click", () => {
            passwordForm.style.display = "block";
            showPasswordBtn.style.display = "none";
        });
    }

    

    if (usernameForm) {
        usernameForm.addEventListener("submit", e => {
            e.preventDefault();
            fetch("../api/update_user.php", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    action: "update_username",
                    username: document.getElementById("new-username").value
                })
            })
            .then(res => res.json())
            .then(data => {
                accountMsg.textContent = data.success
                    ? "✅ Pseudo mis à jour avec succès."
                    : "❌ Erreur lors de la mise à jour.";
            });
        });
    }

    if (passwordForm) {
        passwordForm.addEventListener("submit", e => {
            e.preventDefault();
            fetch("../api/update_user.php", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    action: "update_password",
                    password: document.getElementById("new-password").value
                })
            })
            .then(res => res.json())
            .then(data => {
                accountMsg.textContent = data.success
                    ? "✅ Mot de passe modifié avec succès."
                    : "❌ Erreur lors de la modification.";
            });
        });
    }

    if (deleteForm) {
        deleteForm.addEventListener("submit", e => {
            e.preventDefault();
            if (confirm("Voulez-vous vraiment supprimer votre compte ?")) {
                fetch("../api/update_user.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ action: "delete_account" })
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        alert("Compte supprimé avec succès.");
                        window.location.href = "../auth/logout.php";
                    } else {
                        accountMsg.textContent = "❌ Erreur lors de la suppression du compte.";
                    }
                });
            }
        });
    }
});