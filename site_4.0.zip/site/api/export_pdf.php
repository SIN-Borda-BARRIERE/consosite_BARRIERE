<?php
echo "Fonction d'export PDF à implémenter.";
?>
